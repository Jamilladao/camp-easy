function bookNow() {
  alert("Booking system is coming soon!");
}
function readReviews() {
  alert("Reviews page is under construction!");
}